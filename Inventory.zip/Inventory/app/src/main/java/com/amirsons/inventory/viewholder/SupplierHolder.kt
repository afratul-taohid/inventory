package com.amirsons.inventory.viewholder

import android.view.View

import com.amirsons.inventory.adapter.base.BaseRecyclerViewHolder
import com.amirsons.inventory.event.OnSupplierItemClickedListener
import com.amirsons.inventory.model.Customer

class SupplierHolder(itemView: View) : BaseRecyclerViewHolder<Customer, OnSupplierItemClickedListener>(itemView) {

    override fun onBindView(item: Customer, position: Int, listener: OnSupplierItemClickedListener?) {
        enableItemViewClick(item, listener)
    }
}
