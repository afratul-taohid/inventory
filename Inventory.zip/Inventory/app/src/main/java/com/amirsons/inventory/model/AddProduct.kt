package com.amirsons.inventory.model

data class AddProduct (
        var name: String?,
        var category: String?,
        var subCategory: String?,
        var unit: Int,
        var unitPrice: Float,
        var total: Float)
