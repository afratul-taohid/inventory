package com.amirsons.inventory.viewholder

import android.view.View
import com.amirsons.inventory.adapter.base.BaseRecyclerViewHolder
import com.amirsons.inventory.event.OnCustomerItemClickedListener
import com.amirsons.inventory.model.Customer

class CustomerHolder(itemView: View) : BaseRecyclerViewHolder<Customer, OnCustomerItemClickedListener>(itemView) {

    override fun onBindView(item: Customer, position: Int, listener: OnCustomerItemClickedListener?) {
        enableItemViewClick(item, listener)
    }
}
