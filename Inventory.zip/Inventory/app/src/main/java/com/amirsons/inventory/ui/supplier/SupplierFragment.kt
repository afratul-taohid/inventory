package com.amirsons.inventory.ui.supplier


import android.os.Bundle
import androidx.core.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.view.View
import android.view.ViewGroup
import com.amirsons.inventory.R
import com.amirsons.inventory.adapter.RecyclerViewAdapter
import com.amirsons.inventory.adapter.base.BaseRecyclerViewHolder
import com.amirsons.inventory.event.OnSupplierItemClickedListener
import com.amirsons.inventory.model.Customer
import com.amirsons.inventory.ui.base.BaseFragment
import com.amirsons.inventory.viewholder.SupplierHolder
import kotlinx.android.synthetic.main.fragment_supplier.*
import java.util.*

/**
 * A simple [Fragment] subclass.
 */
class SupplierFragment : BaseFragment(), SupplierView, OnSupplierItemClickedListener {

    private lateinit var mSupplierPresenter: SupplierPresenter

    override val contentLayout: Int
        get() = R.layout.fragment_supplier

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mSupplierPresenter = SupplierMvp(this)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setToolbar(view, mSupplierPresenter.context.getString(R.string.action_suppliers), false)

        val layoutManager = LinearLayoutManager(mSupplierPresenter.context)
        rv_supplier_list.layoutManager = layoutManager

        mSupplierPresenter.onLoadList()
    }

    override fun setListToView(supplierList: ArrayList<Customer>) {

        val mSupplierAdapter = object : RecyclerViewAdapter<Customer, OnSupplierItemClickedListener>(supplierList) {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseRecyclerViewHolder<Customer, OnSupplierItemClickedListener> {
                return SupplierHolder(inflate(R.layout.item_supplier, parent))
            }
        }

        mSupplierAdapter.setListener(this)
        rv_supplier_list.adapter = mSupplierAdapter
    }

    override fun onSingleViewClicked(v: View, position: Int) {

    }

    override fun onItemClickListener(item: Customer, position: Int) {

    }

    companion object {

        val instance: SupplierFragment
            get() {
                val fragment = SupplierFragment()
                val args = Bundle()
                fragment.arguments = args
                return fragment
            }
    }
}
