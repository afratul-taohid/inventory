package com.amirsons.inventory.ui.base

import android.content.Intent

interface OnActivityResultListener {
    fun onResultSuccess(resultCode: Int, data: Intent)
    fun onResultError(resultCode: Int, data: Intent)
}