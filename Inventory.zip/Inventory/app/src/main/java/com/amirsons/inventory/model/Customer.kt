package com.amirsons.inventory.model

data class Customer (
        var name: String?,
        var amount: String?,
        var lastInvoiceDate: String?)
