package com.amirsons.inventory.model

data class Brand(var name: String?)
