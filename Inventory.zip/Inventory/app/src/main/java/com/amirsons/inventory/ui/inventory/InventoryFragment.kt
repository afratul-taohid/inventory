package com.amirsons.inventory.ui.inventory


import android.os.Bundle
import androidx.core.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.view.View
import android.view.ViewGroup
import com.amirsons.inventory.R
import com.amirsons.inventory.adapter.RecyclerViewAdapter
import com.amirsons.inventory.adapter.base.BaseRecyclerClickListener
import com.amirsons.inventory.adapter.base.BaseRecyclerViewHolder
import com.amirsons.inventory.event.OnProductItemClickedListener
import com.amirsons.inventory.model.Brand
import com.amirsons.inventory.model.Product
import com.amirsons.inventory.ui.base.BaseFragment
import com.amirsons.inventory.viewholder.BrandHolder
import com.amirsons.inventory.viewholder.ProductHolder
import kotlinx.android.synthetic.main.fragment_inventory.*

/**
 * A simple [Fragment] subclass.
 */
class InventoryFragment : BaseFragment(), InventoryView, BaseRecyclerClickListener<Brand> {

    private lateinit var mInventoryPresenter: InventoryPresenter

    override val contentLayout: Int
        get() = R.layout.fragment_inventory

    companion object {
        val instance: InventoryFragment
            get() {
                val fragment = InventoryFragment()
                val args = Bundle()
                fragment.arguments = args
                return fragment
            }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mInventoryPresenter = InventoryMvp(this)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setToolbar(view, mInventoryPresenter.context.getString(R.string.action_inventory), false)

        val verticalManager = LinearLayoutManager(mInventoryPresenter.context)
        rv_product_list.layoutManager = verticalManager

        val horizontalManager = LinearLayoutManager(mInventoryPresenter.context, LinearLayoutManager.HORIZONTAL, false)
        rv_brand_name_list.layoutManager = horizontalManager

        mInventoryPresenter.onLoadList()
    }

    override fun setBrandListToView(brandList: ArrayList<Brand>) {

        val mBrandAdapter = object : RecyclerViewAdapter<Brand, BaseRecyclerClickListener<Brand>>(brandList) {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseRecyclerViewHolder<Brand, BaseRecyclerClickListener<Brand>> {
                return BrandHolder(inflate(R.layout.item_brand, parent))
            }
        }
        mBrandAdapter.setListener(this)
        rv_brand_name_list.adapter = mBrandAdapter
    }

    override fun setProductListToView(productList: ArrayList<Product>) {

        val mProductAdapter = object : RecyclerViewAdapter<Product, OnProductItemClickedListener>(productList) {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseRecyclerViewHolder<Product, OnProductItemClickedListener> {
                return ProductHolder(inflate(R.layout.item_inventory, parent))
            }
        }

        mProductAdapter.setListener(object : OnProductItemClickedListener {
            override fun onSingleViewClicked(v: View, position: Int) {

            }

            override fun onItemClickListener(item: Product, position: Int) {

            }
        })
        rv_product_list.adapter = mProductAdapter
    }

    override fun onItemClickListener(item: Brand, position: Int) {

    }
}
