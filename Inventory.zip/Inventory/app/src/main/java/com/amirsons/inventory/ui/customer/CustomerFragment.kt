package com.amirsons.inventory.ui.customer


import android.os.Bundle
import androidx.core.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.view.View
import android.view.ViewGroup
import com.amirsons.inventory.R
import com.amirsons.inventory.adapter.RecyclerViewAdapter
import com.amirsons.inventory.adapter.base.BaseRecyclerViewHolder
import com.amirsons.inventory.event.OnCustomerItemClickedListener
import com.amirsons.inventory.model.Customer
import com.amirsons.inventory.ui.base.BaseFragment
import com.amirsons.inventory.viewholder.CustomerHolder
import kotlinx.android.synthetic.main.fragment_customer.*
import java.util.*


/**
 * A simple [Fragment] subclass.
 */
class CustomerFragment : BaseFragment(), CustomerView, OnCustomerItemClickedListener {
    
    override val contentLayout: Int
        get() = R.layout.fragment_customer
    
    private lateinit var mCustomerPresenter: CustomerPresenter

    companion object {

        val instance: CustomerFragment
            get() {
                val fragment = CustomerFragment()
                val args = Bundle()
                fragment.arguments = args
                return fragment
            }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mCustomerPresenter = CustomerMvp(this)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setToolbar(view, mCustomerPresenter.context.getString(R.string.action_customer), false)

        val layoutManager = LinearLayoutManager(mCustomerPresenter.context)
        rv_customer_list.layoutManager = layoutManager
        mCustomerPresenter.onLoadList()
    }

    override fun setListToView(customerList: ArrayList<Customer>) {

        val mCustomerAdapter = object : RecyclerViewAdapter<Customer, OnCustomerItemClickedListener>(customerList) {

            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseRecyclerViewHolder<Customer, OnCustomerItemClickedListener> {
                return CustomerHolder(inflate(R.layout.item_customer, parent))
            }
        }

        mCustomerAdapter.setListener(this)
        rv_customer_list.adapter = mCustomerAdapter
    }

    override fun onSingleViewClicked(v: View, position: Int) {

    }

    override fun onItemClickListener(item: Customer, position: Int) {

    }
}
