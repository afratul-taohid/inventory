package com.amirsons.inventory.viewholder

/* Created by Imran Khan on 20-Jun-19.
 * Copyright (c) Imran Khan All rights reserved.*/

import android.view.View
import com.amirsons.inventory.adapter.base.BaseRecyclerViewHolder
import com.amirsons.inventory.event.OnProductItemClickedListener
import com.amirsons.inventory.model.Product

class ProductHolder(itemView: View) : BaseRecyclerViewHolder<Product, OnProductItemClickedListener>(itemView) {

    override fun onBindView(item: Product, position: Int, listener: OnProductItemClickedListener?) {
        enableItemViewClick(item, listener)
    }
}
