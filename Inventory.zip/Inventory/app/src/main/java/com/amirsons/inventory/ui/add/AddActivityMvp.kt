package com.amirsons.inventory.ui.add

import com.amirsons.inventory.model.AddProduct
import com.amirsons.inventory.model.Brand
import com.amirsons.inventory.model.Product
import com.amirsons.inventory.ui.base.BasePresenter
import com.amirsons.inventory.ui.base.BaseView
import java.util.ArrayList

/**
 * Created by Taohid on 06, July, 2019
 * Email: taohid32@gmail.com
 */

internal interface AddActivityView : BaseView {

    fun setListToView(productList: ArrayList<AddProduct>)
    fun setAvailableList(availableList: ArrayList<Product>)
    fun setBrandList(brandList: ArrayList<Brand>)
}

internal interface AddActivityPresenter : BasePresenter {
    fun onLoadList()
    fun onLoadAvailable()
    fun onLoadBrand()
}

class AddActivityMvp internal constructor(private val mAddView: AddActivityView) : AddActivityPresenter {

    override fun onLoadList() {

        val products = ArrayList<AddProduct>()

        for (i in 0..0) {
            val product = AddProduct("Sun", "(A/C)", "300gsm", 3, 200f, (200 * 3).toFloat())
            products.add(product)
        }

        mAddView.setListToView(products)
    }

    override fun onLoadAvailable() {

        val products = ArrayList<Product>()
        for (i in 0..2) {
            val product = Product("(A/C)", "300gsm", "20 unit", "22x18", "21/06/2019")
            products.add(product)
        }
        mAddView.setAvailableList(products)
    }

    override fun onLoadBrand() {

        val brands = ArrayList<Brand>()
        for (i in 0..9) {
            val brand = Brand("Panda")
            brands.add(brand)
        }
        mAddView.setBrandList(brands)
    }
}