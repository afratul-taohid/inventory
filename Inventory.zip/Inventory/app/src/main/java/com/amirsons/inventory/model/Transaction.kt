package com.amirsons.inventory.model

data class Transaction(
        var name: String?,
        var price: String?,
        var date: String?)
