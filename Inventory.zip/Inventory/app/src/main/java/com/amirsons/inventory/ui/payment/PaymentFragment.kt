package com.amirsons.inventory.ui.payment


import android.os.Bundle
import androidx.core.app.Fragment
import android.view.View

import com.amirsons.inventory.R
import com.amirsons.inventory.ui.base.BaseFragment

/**
 * A simple [Fragment] subclass.
 */
class PaymentFragment : BaseFragment(), PaymentView {

    private lateinit var presenter: PaymentPresenter

    override val contentLayout: Int
        get() = R.layout.fragment_payment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        presenter = PaymentMvp(this)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
    }
}
