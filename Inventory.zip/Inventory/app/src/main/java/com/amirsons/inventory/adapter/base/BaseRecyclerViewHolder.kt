package com.amirsons.inventory.adapter.base

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.View
import com.amirsons.inventory.utils.OnSingleClickListener

/**
 * Created by taohid on 19,February, 2019
 * Email: taohid32@gmail.com
 */

abstract class BaseRecyclerViewHolder<T, L : BaseRecyclerClickListener<*>>(itemView: View) : RecyclerView.ViewHolder(itemView) {

    var context: Context = itemView.context

    abstract fun onBindView(item: T, position: Int, listener: L?)

    fun enableItemViewClick(item: T, baseRecyclerClickListener: BaseRecyclerClickListener<T>?) {

        itemView.setOnClickListener(object : OnSingleClickListener() {

            override fun onSingleClick(v: View) {

                baseRecyclerClickListener?.onItemClickListener(item, adapterPosition)
            }
        })
    }
}
