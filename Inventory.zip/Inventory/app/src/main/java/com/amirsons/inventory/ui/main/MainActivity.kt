package com.amirsons.inventory.ui.main

import android.os.Bundle
import android.view.MenuItem
import androidx.fragment.app.Fragment
import com.amirsons.inventory.R
import com.amirsons.inventory.ui.base.BaseActivity
import com.amirsons.inventory.ui.home.HomeFragment
import com.amirsons.inventory.ui.inventory.InventoryFragment
import com.amirsons.inventory.ui.more.MoreFragment
import com.amirsons.inventory.ui.sales.SalesFragment
import com.amirsons.inventory.ui.supplies.SuppliesFragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : BaseActivity() {

    override val contentLayout: Int
        get() = R.layout.activity_main

    private val onNavigationItemSelectedListener = object  : BottomNavigationView.OnNavigationItemSelectedListener {

        override fun onNavigationItemSelected(p0: MenuItem): Boolean {

            when (p0.itemId) {

                R.id.menu_home -> {
                    onFragmentTransaction(HomeFragment.instance)
                    return true
                }

                R.id.menu_sales -> {
                    onFragmentTransaction(SalesFragment.instance)
                    return true
                }

                R.id.menu_inventory -> {
                    onFragmentTransaction(InventoryFragment.instance)
                    return true
                }

                R.id.menu_supplies -> {
                    onFragmentTransaction(SuppliesFragment.instance)
                    return true
                }

                R.id.menu_more -> {
                    onFragmentTransaction(MoreFragment.instance)
                    return true
                }
            }

            return false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        bottom_navigation.setOnNavigationItemSelectedListener(onNavigationItemSelectedListener)
    }

    private fun onFragmentTransaction(fragment: Fragment) {
        val manager = supportFragmentManager
        val transaction = manager.beginTransaction()
        transaction.replace(R.id.fragment_container, fragment).commit()
    }
}
