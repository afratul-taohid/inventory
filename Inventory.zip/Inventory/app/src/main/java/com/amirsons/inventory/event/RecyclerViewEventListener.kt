package com.amirsons.inventory.event

import android.view.View

import com.amirsons.inventory.adapter.base.BaseRecyclerClickListener
import com.amirsons.inventory.model.Customer
import com.amirsons.inventory.model.Product

interface OnCustomerItemClickedListener : BaseRecyclerClickListener<Customer> {
    fun onSingleViewClicked(v: View, position: Int)
}

interface OnProductItemClickedListener : BaseRecyclerClickListener<Product> {
    fun onSingleViewClicked(v: View, position: Int)
}

interface OnSupplierItemClickedListener : BaseRecyclerClickListener<Customer> {
    fun onSingleViewClicked(v: View, position: Int)
}