package com.amirsons.inventory.ui.customer

import com.amirsons.inventory.model.Customer
import com.amirsons.inventory.ui.base.BasePresenter
import com.amirsons.inventory.ui.base.BaseView
import java.util.ArrayList

/**
 * Created by Taohid on 06, July, 2019
 * Email: taohid32@gmail.com
 */

internal interface CustomerView : BaseView {
    fun setListToView(customerList: ArrayList<Customer>)
}

internal interface CustomerPresenter : BasePresenter {
    fun onLoadList()
}

class CustomerMvp internal constructor(private val mCustomerView: CustomerView) : CustomerPresenter {

    override fun onLoadList() {

        val customerList = ArrayList<Customer>()

        for (i in 0..9) {
            val customer = Customer("Alam trading", "30৳", "25/4/2019")
            customerList.add(customer)
        }

        mCustomerView.setListToView(customerList)
    }
}