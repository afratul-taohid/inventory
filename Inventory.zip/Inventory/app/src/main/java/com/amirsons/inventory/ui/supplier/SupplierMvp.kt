package com.amirsons.inventory.ui.supplier

import com.amirsons.inventory.model.Customer
import com.amirsons.inventory.ui.base.BasePresenter
import com.amirsons.inventory.ui.base.BaseView
import java.util.*

internal interface SupplierView : BaseView {
    fun setListToView(supplierList: ArrayList<Customer>)
}

internal interface SupplierPresenter : BasePresenter {
    fun onLoadList()
}

class SupplierMvp internal constructor(private val mSupplierView: SupplierView) : SupplierPresenter {

    override fun onLoadList() {

        val supplierList = ArrayList<Customer>()
        for (i in 0..9) {
            val supplier = Customer("Alam trading", "30৳", "25/4/2019")
            supplierList.add(supplier)
        }
        mSupplierView.setListToView(supplierList)
    }
}
