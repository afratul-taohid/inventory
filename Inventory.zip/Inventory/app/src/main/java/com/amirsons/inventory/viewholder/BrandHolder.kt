package com.amirsons.inventory.viewholder

import android.view.View
import com.amirsons.inventory.adapter.base.BaseRecyclerClickListener
import com.amirsons.inventory.adapter.base.BaseRecyclerViewHolder
import com.amirsons.inventory.model.Brand

class BrandHolder(itemView: View) : BaseRecyclerViewHolder<Brand, BaseRecyclerClickListener<Brand>>(itemView) {

    override fun onBindView(item: Brand, position: Int, listener: BaseRecyclerClickListener<Brand>?) {
        enableItemViewClick(item, listener)
    }
}
