package com.amirsons.inventory.viewholder

import android.view.View

import com.amirsons.inventory.adapter.base.BaseRecyclerClickListener
import com.amirsons.inventory.adapter.base.BaseRecyclerViewHolder
import com.amirsons.inventory.model.Transaction

class UnpaidHolder(itemView: View) : BaseRecyclerViewHolder<Transaction, BaseRecyclerClickListener<Transaction>>(itemView) {

    override fun onBindView(item: Transaction, position: Int, listener: BaseRecyclerClickListener<Transaction>?) {
        enableItemViewClick(item, listener)
    }
}
