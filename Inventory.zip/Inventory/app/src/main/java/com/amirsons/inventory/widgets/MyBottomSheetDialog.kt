package com.amirsons.inventory.widgets

import android.content.Context
import android.support.design.widget.BottomSheetDialog

import com.amirsons.inventory.R

class MyBottomSheetDialog(context: Context) : BottomSheetDialog(context, R.style.BottomSheetDialog)
