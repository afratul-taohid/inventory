package com.amirsons.inventory.ui.more

import android.os.Bundle
import android.view.View
import com.amirsons.inventory.R
import com.amirsons.inventory.ui.FragmentContainerActivity
import com.amirsons.inventory.ui.base.BaseFragment
import com.amirsons.inventory.utils.IntentUtils
import kotlinx.android.synthetic.main.fragment_more.*

/**
 * A simple [Fragment] subclass.
 */
class MoreFragment : BaseFragment(), MoreView, View.OnClickListener {

    private lateinit var mMorePresenter: MorePresenter

    override val contentLayout: Int
        get() = R.layout.fragment_more

    companion object {

        val instance: MoreFragment
            get() {
                val fragment = MoreFragment()
                val args = Bundle()
                fragment.arguments = args
                return fragment
            }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mMorePresenter = MoreMvp(this)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setToolbar(view, mMorePresenter.context.getString(R.string.action_more), false)

        btn_event_transaction.setOnClickListener(this)
        btn_event_customer.setOnClickListener(this)
        btn_event_supplier.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.btn_event_transaction -> onNavigation(1)
            R.id.btn_event_customer -> onNavigation(2)
            R.id.btn_event_supplier -> onNavigation(3)
        }
    }

    private fun onNavigation(extra: Int) {
        val bundle = Bundle()
        bundle.putInt("FRAGMENT_TYPE_EXTRA", extra)
        IntentUtils.instance.onActivityIntentWithExtras(context, FragmentContainerActivity::class.java, bundle)
    }
}
