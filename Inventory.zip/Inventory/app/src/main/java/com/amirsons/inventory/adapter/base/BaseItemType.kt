package com.amirsons.inventory.adapter.base

/**
 * Created by Taohid on 3/17/19.
 * Email: taohid32@gmail.com
 */
interface BaseItemType {
    val type: Short
}
