package com.amirsons.inventory.ui.inventory

import com.amirsons.inventory.model.Brand
import com.amirsons.inventory.model.Product
import com.amirsons.inventory.ui.base.BasePresenter
import com.amirsons.inventory.ui.base.BaseView
import java.util.*

internal interface InventoryView : BaseView {
    fun setBrandListToView(brandList: ArrayList<Brand>)
    fun setProductListToView(productList: ArrayList<Product>)
}

internal interface InventoryPresenter : BasePresenter {
    fun onLoadList()
}

class InventoryMvp internal constructor(private val mInventoryView: InventoryView) : InventoryPresenter {

    override fun onLoadList() {

        val products = ArrayList<Product>()
        val brands = ArrayList<Brand>()

        for (i in 0..9) {
            val product = Product("(A/C)", "300gsm", "20 unit", "22x18", "21/06/2019")
            products.add(product)
        }
        for (i in 0..4) {
            val brand = Brand("Panda")
            brands.add(brand)
        }

        mInventoryView.setProductListToView(products)
        mInventoryView.setBrandListToView(brands)
    }
}
