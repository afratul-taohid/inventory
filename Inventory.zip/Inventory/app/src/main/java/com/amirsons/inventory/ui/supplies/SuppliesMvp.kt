package com.amirsons.inventory.ui.supplies

class SuppliesMvp
