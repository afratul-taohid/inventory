package com.amirsons.inventory.model

/* Created by Imran Khan on 20-Jun-19.
 * Copyright (c) Imran Khan All rights reserved.*/

data class Product(
        var category: String?,
        var subCategory: String?,
        var unitAmount: String?,
        var size: String?,
        var lastSupply: String?)
