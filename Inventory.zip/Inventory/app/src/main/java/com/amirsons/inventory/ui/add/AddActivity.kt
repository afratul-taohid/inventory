package com.amirsons.inventory.ui.add

import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager

import com.amirsons.inventory.R
import com.amirsons.inventory.adapter.RecyclerViewAdapter
import com.amirsons.inventory.adapter.base.BaseRecyclerClickListener
import com.amirsons.inventory.adapter.base.BaseRecyclerViewHolder
import com.amirsons.inventory.model.AddProduct
import com.amirsons.inventory.model.Brand
import com.amirsons.inventory.model.Product
import com.amirsons.inventory.ui.base.BaseActivity
import com.amirsons.inventory.viewholder.AddProductHolder
import com.amirsons.inventory.viewholder.AvailableProductHolder
import com.amirsons.inventory.viewholder.BrandHolder
import com.amirsons.inventory.widgets.MyBottomSheetDialog
import kotlinx.android.synthetic.main.activity_add.*
import kotlinx.android.synthetic.main.dialog_available_product.*
import java.util.ArrayList

class AddActivity : BaseActivity(), AddActivityView, View.OnClickListener {

    private lateinit var mAddPresenter: AddActivityPresenter

    private lateinit var bottomSheetDialog: MyBottomSheetDialog

    override val contentLayout: Int
        get() = R.layout.activity_add

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        mAddPresenter = AddActivityMvp(this)

        val layoutManager = LinearLayoutManager(this)
        rv_add_product_list.layoutManager = layoutManager

        mAddPresenter.onLoadList()

        btn_add_product.setOnClickListener(this)
    }

    private fun showAddProductDialog() {

        bottomSheetDialog = MyBottomSheetDialog(this)
        bottomSheetDialog.setContentView(R.layout.dialog_available_product)

        bottomSheetDialog.btn_add_new_product.setOnClickListener(this)

        val mBrandLayoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        val mAvailableLayoutManager = LinearLayoutManager(this)

        bottomSheetDialog.rv_brand_name_list.layoutManager = mBrandLayoutManager
        bottomSheetDialog.rv_available_product_list.layoutManager = mAvailableLayoutManager

        mAddPresenter.onLoadAvailable()
        mAddPresenter.onLoadBrand()

        bottomSheetDialog.show()
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.btn_add_product -> showAddProductDialog()
            R.id.btn_add_new_product -> showNewAddProductDialog()
        }
    }

    override fun onBackPressed() {
        finish()
    }

    private fun showNewAddProductDialog() {
        val bottomSheetDialog = MyBottomSheetDialog(this)
        bottomSheetDialog.setContentView(R.layout.dialog_add_product)
        bottomSheetDialog.show()
    }

    override fun setListToView(productList: ArrayList<AddProduct>) {

        val mProductAdapter = object : RecyclerViewAdapter<AddProduct, BaseRecyclerClickListener<AddProduct>>(productList) {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseRecyclerViewHolder<AddProduct, BaseRecyclerClickListener<AddProduct>> {
                return AddProductHolder(inflate(R.layout.item_add_product, parent))
            }
        }

        mProductAdapter.setListener(object : BaseRecyclerClickListener<AddProduct>{

            override fun onItemClickListener(item: AddProduct, position: Int) {
                TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
            }
        })

        rv_add_product_list.adapter = mProductAdapter
        tv_item_selected_count.text = String.format("%s item selected", productList.size)
    }

    override fun setAvailableList(availableList: ArrayList<Product>) {

        val mAvailableAdapter = object : RecyclerViewAdapter<Product, BaseRecyclerClickListener<Product>>(availableList) {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseRecyclerViewHolder<Product, BaseRecyclerClickListener<Product>> {
                return AvailableProductHolder(inflate(R.layout.item_available_product, parent))
            }
        }

        bottomSheetDialog.rv_available_product_list.adapter = mAvailableAdapter
    }

    override fun setBrandList(brandList: ArrayList<Brand>) {

        val mBrandAdapter = object : RecyclerViewAdapter<Brand, BaseRecyclerClickListener<Brand>>(brandList) {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseRecyclerViewHolder<Brand, BaseRecyclerClickListener<Brand>> {
                return BrandHolder(inflate(R.layout.item_brand, parent))
            }
        }

        bottomSheetDialog.rv_brand_name_list.adapter = mBrandAdapter
    }
}
